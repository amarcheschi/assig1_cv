import numpy as np
import cv2


def _erode_bool(mask_bool: np.ndarray, px: int = 1) -> np.ndarray:
    """Erode a bool mask to drop the warp-interpolation fringe."""
    if px <= 0 or not mask_bool.any():
        return mask_bool
    k = np.ones((3, 3), np.uint8)
    return cv2.erode(mask_bool.astype(np.uint8), k,
                      iterations=int(px)).astype(bool)


def feather_weights(masks, erode_px: int = 2):
    """Distance-transform weights: 0 at mask borders, no black bleed.

    Gaussian-blurred binary masks stay >0 outside the valid footprint,
    so ``w * warped`` mixes real pixels with black background and the
    blurred rectangle stays visible as a translucent seam. Distance
    values are exactly 0 outside the (eroded) mask, so invalid pixels
    can never contribute.
    Returns (weights, union) with union the eroded coverage.
    """
    eroded = [_erode_bool(np.asarray(m, dtype=bool), erode_px) for m in masks]
    dists = []
    for m in eroded:
        if m.any():
            d = cv2.distanceTransform(m.astype(np.uint8), cv2.DIST_L2, 3)
        else:
            d = np.zeros(m.shape, dtype=np.float32)
        dists.append(d.astype(np.float32))
    denom = sum(dists)
    union = eroded[0].copy()
    for m in eroded[1:]:
        union |= m
    weights = []
    for d in dists:
        w = np.zeros(d.shape, dtype=np.float32)
        nz = (denom > 1e-6) & union
        w[nz] = d[nz] / denom[nz]
        weights.append(w)
    return weights, union


def compose_imgs(img1: np.ndarray, img2: np.ndarray, H: np.ndarray,
                 blend: str = "average",
                 ):
    """
    Compose 2 images given the transformation warping matrix of the second.

    :param img1: Image kept untransformed (reference)
    :param img2: Image to be warped
    :param H: 3x3 homography / projective transformation matrix
    :param blend: 'average' (baseline) or 'feather' (distance-based)
    :return: (imgcomposed, displacement)
             - imgcomposed: The blended composite image
             - displacement: [ty, tx] translation applied to img1
    """

    # image shape is (height, width) or (height, width, channels)
    sizey, sizex = img1.shape[:2]

    # 0-based pixel corners of the image to warp: (0,0),(0,h),(w,h),(w,0).
    # (The old code used 1-based corners, shifting the canvas by 1px and
    # leaving a 1px misregistration seam between ref and warped image.)
    h2, w2 = img2.shape[:2]
    corners = np.array(
        [[0, 0, 1], [0, h2, 1], [w2, h2, 1], [w2, 0, 1]],
        dtype=np.float64,
    )

    # Project corners through H: cornersh = (H @ corners.T).T
    projected = (H @ corners.T).T
    cornersh = projected[:, :2] / projected[:, 2:3]

    minvals = np.min(cornersh, axis=0)
    maxvals = np.max(cornersh, axis=0)

    # Union of the ref footprint [(0,0)-(sizex,sizey)] and the warped one.
    minx = min(0.0, float(minvals[0]))
    miny = min(0.0, float(minvals[1]))
    maxx = max(float(sizex), float(maxvals[0]))
    maxy = max(float(sizey), float(maxvals[1]))

    # Determine shift/translation if warped image spills left or top
    tx = int(-np.floor(minx)) if minx < 0 else 0
    ty = int(-np.floor(miny)) if miny < 0 else 0

    new_w = int(np.ceil(maxx)) + tx
    new_h = int(np.ceil(maxy)) + ty

    # Translation matrix to shift origin by (tx, ty)
    T = np.array([[1.0, 0.0, tx], [0.0, 1.0, ty], [0.0, 0.0, 1.0]])

    # Combined homography that warps and applies translation shift
    H_translated = T @ H

    # Warp img2 into the expanded canvas
    # Note: cv2.warpPerspective expects dsize=(width, height)
    img2_warped = cv2.warpPerspective(img2, H_translated, (new_w, new_h))

    # Place img1 shifted by (tx, ty) onto its canvas
    if img1.ndim == 3:
        newimg1 = np.zeros((new_h, new_w, img1.shape[2]), dtype=img1.dtype)
    else:
        newimg1 = np.zeros((new_h, new_w), dtype=img1.dtype)

    newimg1[ty : ty + sizey, tx : tx + sizex] = img1

    # Masks for compositing: 1 where each image contributes. Erode the
    # warped mask by 1px: INTER_NEAREST on the mask covers a slightly
    # larger footprint than the INTER_LINEAR image warp, so the raw mask
    # ring would average/blend black fringe pixels into the seam.
    mask1 = np.zeros((new_h, new_w), dtype=np.uint8)
    mask1[ty : ty + sizey, tx : tx + sizex] = 1
    mask2_src = np.ones((h2, w2), dtype=np.uint8) * 255
    mask2 = cv2.warpPerspective(mask2_src, H_translated, (new_w, new_h),
                                flags=cv2.INTER_NEAREST) > 0

    # Compose with averaging in the overlap region (2D masks index HxW,
    # which NumPy broadcasts correctly for both gray and color images)
    m1 = _erode_bool(mask1.astype(bool), 1)
    m2 = _erode_bool(np.asarray(mask2, dtype=bool), 1)
    only1 = m1 & ~m2
    only2 = m2 & ~m1
    both = m1 & m2
    imgcomposed = np.zeros_like(newimg1)
    imgcomposed[only1] = newimg1[only1]
    imgcomposed[only2] = img2_warped[only2]
    avg = ((newimg1.astype(np.float32) + img2_warped.astype(np.float32)) / 2.0)
    imgcomposed[both] = avg[both].astype(img1.dtype)

    displacement = [ty, tx]

    if blend == "feather":
        weights, union = feather_weights([m1, m2], erode_px=2)
        w1, w2 = weights
        f1 = newimg1.astype(np.float32)
        f2 = img2_warped.astype(np.float32)
        if f1.ndim == 3:
            w1 = w1[:, :, None]
            w2 = w2[:, :, None]
        imgcomposed = (w1 * f1 + w2 * f2).astype(img1.dtype)
        imgcomposed[~union] = 0
    elif blend != "average":
        raise ValueError("blend must be 'average' or 'feather'")

    return imgcomposed, displacement
