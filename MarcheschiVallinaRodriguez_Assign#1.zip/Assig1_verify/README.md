# Assignment 1 — Keypoint Detectors, Feature Descriptors and Image Stitching

**Course:** Artificial Intelligence for (Advanced) Computer Vision — 2026/27
**Assignment #1:** Keypoint Detectors, Feature Descriptors and Applications

Feature-based computer-vision pipeline in Python/OpenCV covering the whole
assignment:

- **Part 1** (`main.py`, `src/`) — keypoint detectors, local descriptors and
  feature matchers, evaluated quantitatively with the reference protocol
  (§2.7–§2.8 of the brief).
- **Part 2** (`pano.py`, `src/`) — the complete feature-based image-stitching
  pipeline (§3), including RANSAC homography, warping, canvas construction,
  blending and multi-image panoramas.

Every number and figure in the report is produced by the commands in this
README. The high-level `cv2.Stitcher` is **not** used anywhere — the pipeline is
implemented from the individual building blocks, as §11 of the brief requires.

---

## 1. Requirements

### 1.1 Software

| Component | Version used | Notes |
|---|---|---|
| Python | **3.12** (brief requires ≥ 3.10) | tested on Windows, CPU-only |
| OpenCV | **4.13.0.92** (`opencv-python` + `opencv-contrib-python`) | `xfeatures2d` needed for BRIEF/FREAK |
| NumPy | ≥ 1.23 | |
| SciPy | ≥ 1.9 | KD-tree for repeatability |
| Matplotlib | ≥ 3.6 | figures |
| scikit-image | ≥ 0.19 | optional image utilities |
| pandas | ≥ 1.5 | result tables (CSV) |
| psutil | ≥ 5.9 | optional memory measurement |
| PyTorch | ≥ 2.0 | **only** for the learned paths (SuperPoint / LightGlue) |
| torchvision | ≥ 0.15 | learned paths |
| transformers | ≥ 4.40 | SuperPoint + LightGlue via Hugging Face |
| Pillow | ≥ 9.0 | learned paths |

The exact specification is in [`requirements.txt`](requirements.txt).

### 1.2 CPU or GPU

**All reported experiments are CPU-only.** The learned paths
(`SuperPoint` / `LightGlue`) automatically use CUDA if available
(`device="cuda"` when `torch.cuda.is_available()`, otherwise `"cpu"`); a GPU is
optional and would only change the absolute timings of the learned methods, not
the relative conclusions. Pass `--device cuda` (or `cpu`) to force one.

### 1.3 Environment setup

With `pip` (recommended, matches `requirements.txt`):

```bash
python -m venv venv            # Python 3.10+ (3.12 used here)
# Windows: venv\Scripts\activate
source venv/bin/activate       # Linux/macOS

pip install -r requirements.txt
```

Or, equivalently, with conda (as suggested in the course demo handout):

```bash
conda create --name cvc python
conda activate cvc
pip install torch torchvision                    # CPU
# pip install torch torchvision --index-url https://download.pytorch.org/whl/cu126   # GPU
pip install numpy scipy matplotlib scikit-image pandas psutil transformers Pillow
pip install opencv-python opencv-contrib-python
```

> **BRIEF / FREAK availability.** SIFT, ORB and KAZE ship with standard
> OpenCV, but BRIEF and FREAK live in `opencv-contrib-python`
> (`cv2.xfeatures2d`). This is documented at run time by
> `src.descriptors.opencv_build_info()`, which is printed by `main.py` and
> stored in `results/notebook_run_config.json`. **SURF is skipped** (optional
> per §2.2; it requires a custom OpenCV build with non-free modules). A
> dependency-free custom BRIEF (NumPy only) is included so the binary-descriptor
> comparison always runs even if `xfeatures2d` is missing.

---

## 2. Data

The brief's datasets are not redistributed (large files). Place them in the
project root exactly as follows.

### 2.1 HPatches — viewpoint changes

Download the full HPatches sequences and extract them into
`hpatches-sequences-release/`:

```bash
# https://huggingface.co/datasets/vbalnt/hpatches
curl -L -o hpatches-sequences-release.zip \
  https://huggingface.co/datasets/vbalnt/hpatches/resolve/main/hpatches-sequences-release.zip
unzip hpatches-sequences-release.zip
```

Each sequence folder contains `1.ppm … 6.ppm` plus the ground-truth
homographies `H_1_2 … H_1_6`. The **viewpoint** experiments use the single
sequence `hpatches-sequences-release/v_bird/1.ppm` (973 × 1068).

### 2.2 HPatches mini — illumination changes

The **illumination** experiments use the shipped mini subset in
`hpatches-mini/`, in particular the sequence `hpatches-mini/i_ajuntament/`
(`1.ppm` is the photometric base image, `2.ppm … 6.ppm` are increasing
illumination changes with shipped `H_1_k`). The subset also contains
`i_dome`, `i_lionday`, `i_veggies`, `i_whitebuilding` and several `v_*`
sequences.

### 2.3 Panorama images (Part 2)

The stitching experiments use the four **keble** images already shipped in
`Data/Panorama/`:

```
Data/Panorama/keble_a.jpg   # 720 × 568
Data/Panorama/keble_b.jpg
Data/Panorama/keble_c.jpg
Data/Panorama/keble_d.jpg   # near-duplicate of keble_c
```

Additional course data (`Data/graf/`, `Data/vehicle-seqs/`) is optional and
not required to reproduce the reported results.

### 2.4 Directory layout after data placement

```
Assig1/
  README.md
  requirements.txt
  main.py                 # Part 1 entry point
  pano.py                 # Part 2 entry point
  src/                    # modules (see §3)
  Data/
    Panorama/keble_{a,b,c,d}.jpg
  hpatches-sequences-release/     # v_bird/ comes from here
  hpatches-mini/                  # i_ajuntament/ comes from here
  results/                # CSV/JSON tables produced by the runs
  figures/                # PNG/JPG figures produced by the runs
```

---

## 3. Code structure

```
src/
  config.py         # ALL thresholds and protocol constants (single source of truth)
  detectors.py      # detector factory: SIFT/ORB/KAZE + FAST+BRIEF/BRISK/FREAK + custom BRIEF
  descriptors.py    # OpenCV build info, descriptor memory table, custom simplified BRIEF
  matching.py       # ratio test, one-to-one filter, cross-check, learned matchers
  homography.py     # synthetic GT homographies, projection, RANSAC estimation + quality
  datasets.py       # synthetic geometric warps, photometric warps, HPatches loading
  evaluation.py     # all metrics + experiment drivers + runtime benchmark
  visualization.py  # keypoint / match / bar-chart figures
  compose2.py       # stitching: canvas, warping, averaging & feathering blends
  __init__.py
main.py             # Part 1 command-line entry point
pano.py             # Part 2 command-line entry point
```

Everything is written as reusable functions (not one long script), with a
command-line entry point for each part, as recommended in §3.1 and §6.

**Legacy / source-material files** kept for reference and *not* part of the
reported pipeline: `part3&4.py`, `decriptorsasigment.py`,
`pano - Copia.py`, the `*.ipynb` notebooks (demos) and the vendored
`SuperGluePretrainedNetwork/` repository. The notebooks are course demos; the
modular `src/` code supersedes them.

---

## 4. Reproducing the experiments

### 4.1 Part 1 — detectors, descriptors and matchers

```bash
# Full classical pipeline (8 configurations), writes results/ and figures/
python main.py

# Same, also appending the learned SuperPoint+NN and SP+LightGlue rows
# (downloads the Hugging Face checkpoints on first use)
python main.py --learned

# Fast smoke test (SIFT + ORB, 2 warps) — ~1 min
python main.py --quick [--learned]

# Show figures interactively instead of only saving them
python main.py --show
```

Useful options: `--base PATH` (base image for the synthetic warps, default
`hpatches-sequences-release/v_bird/1.ppm`), `--outdir DIR` (default `results`),
`--figdir DIR` (default `figures`), `--device {cpu,cuda}`.

**Outputs:** `results/notebook_*.csv` (matching, repeatability, homography,
runtime, descriptor info, ajuntament illumination, synthetic photometric) plus
`results/notebook_run_config.json` (records every threshold, the OpenCV build,
the warp homographies and whether the learned path ran), and the corresponding
figures in `figures/`.

### 4.2 Part 2 — stitching and panoramas

```bash
# Default: three-image panorama of the keble set, middle reference, feathering
python pano.py

# Explicit images, all classical configurations, average baseline, RANSAC 3 px
python pano.py Data/Panorama/keble_a.jpg Data/Panorama/keble_b.jpg \
    Data/Panorama/keble_c.jpg \
    --config SIFT --config ORB --config FAST+BRIEF \
    --blend average --ref 1 --out figures/pano.jpg --stats-out results/pano_stats.csv
```

Important options:

| Option | Meaning |
|---|---|
| positional `images` | images to stitch (default: `keble_a/b/c.jpg`); only these are used |
| `--ref N` | reference image index (default: middle image) |
| `--blend {average,feather}` | compositing rule (default `feather`) |
| `--config NAME` | feature config from `src.detectors` **plus** `SP+LightGlue`; repeatable (default: SIFT, ORB, FAST+BRIEF) |
| `--ratio` | ratio-test threshold (default `0.8`) |
| `--ransac` | RANSAC reprojection threshold in px (default `3.0`) |
| `--out` | output panorama path; with several `--config` values it is used as a stem prefix (`<out>_<config>.jpg`). Default when omitted: `figures/pano_abc.jpg` for one config, otherwise `figures/pano_abc_<config>.jpg` |
| `--matches-prefix` | prefix of the per-pair inlier visualisations |
| `--stats-out` | per-pair stats CSV (default `results/pano_stats.csv`) |
| `--ransac-study` | SIFT-only study over RANSAC thresholds 1/3/5 px (§3.2) |
| `--device`, `--lg-threshold` | learned path device and LightGlue confidence (default `0.1`) |

**Outputs:** the blended panorama, one `*_to_ref.jpg` visualisation per pair
(RANSAC inliers only), and a CSV + JSON with one row per stitched pair
(`n_matches`, `n_inliers`, `inlier_ratio`, mean/median inlier residual, the
detection counts and the pairing).

### 4.3 One-command reproduction of the main results

From the project root, with the data of §2 in place:

```bash
python main.py --learned                                   # Part 1 tables + figures
python pano.py --config SIFT --config ORB --config FAST+BRIEF \
    --out figures/pano_abc.jpg                             # Part 2 panoramas (classical)
python pano.py --config SP+LightGlue --out figures/pano_sp_lightglue.jpg
python pano.py --config SIFT --ransac-study                # RANSAC threshold study
```

The reference-image and blending comparisons of §3.3–§3.4 are reproduced with
`--ref 0|1|2` and `--blend average|feather` (see the report, `Report_Part2.md`
§7, for the exact command list).

---

## 5. Parameters and protocol

All shared values live in [`src/config.py`](src/config.py) so every module uses
the same numbers; this is what the report cites.

**Matching and geometric verification (reference protocol, §2.8)**

| Parameter | Value |
|---|---|
| Ratio test (two best distances) | reject if `d1 / d2 > 0.8` |
| Putative matches | one-to-one greedy pairing (required by §2.8) |
| Correctness radius | `3.0 px` reprojection error |
| RANSAC threshold | `3.0 px` (`cv2.findHomography(..., cv2.RANSAC, 3.0)`) |
| RANSAC study values | `1.0 / 3.0 / 5.0 px` |
| Distance norms | L2 for float descriptors (SIFT/KAZE/SuperPoint), Hamming for binary (ORB/BRIEF/BRISK/FREAK) |
| LightGlue confidence threshold | `0.1` |

**Detectors / descriptors**

| Config | Details |
|---|---|
| SIFT | `cv2.SIFT_create()` (defaults) |
| ORB | `cv2.ORB_create(nfeatures=5000)` |
| KAZE | `cv2.KAZE_create()` (defaults) |
| FAST+* | `cv2.FastFeatureDetector_create()` with NMS on; keypoints fixed to `size = 31`, `octave = 0`, no orientation |
| Custom BRIEF | patch 31, 256 bits (32 bytes), Gaussian pre-blur ksize 5, seed 0; strategies `uniform` and `gaussian` (σ = patch/5) |

**Synthetic warps (viewpoint, exact GT homographies)**

| Warp | Parameters |
|---|---|
| Rotated | 45° about the image centre |
| Translated | (tx, ty) = (100, 50) |
| Scaled 1.5x / 0.5x | resize then centre-crop/pad to the original size |
| Combined | 30° rotation, scale 0.8, + (50, 30) translation |

**Synthetic photometric warps (illumination, geometry = identity)**

`bright+`, `dark+`, `contrast`, `gamma0.5`, `gamma2.0`.

**Real illumination pairs:** `hpatches-mini/i_ajuntament`, pairs `1 → 2, 3, 4, 5, 6`.

---

## 6. Metrics

For every detector/descriptor or detector/matcher configuration, whenever
ground-truth correspondences are available, the pipeline reports (§2.7–§2.8):

- number of detected keypoints and detection **repeatability**;
- number and percentage of **correct matches** (≤ 3 px);
- **PMR** = putative / features;
- **Precision** = correct / putative;
- **Matching Score** = correct / features (= PMR × Precision);
- **Recall** = correct / ground-truth correspondences;
- **homography accuracy**: number of RANSAC inliers, inlier ratio, mean/median
  inlier reprojection error, and the corner-mean error against the GT
  homography;
- **runtime** per stage (detect / describe / match) and **descriptor
  dimensionality / memory**.

Every table carries its denominators (`n_features`, `n_putative`, `n_correct`,
`n_correspondences`) so the values are reproducible. Results are reported
**separately for viewpoint and illumination** categories. Runtime values are
the **median of 5 runs after one discarded warm-up** (`evaluation._bench`).

---

## 7. External implementations and citations

**Pretrained models / code used**

- **SuperPoint** — `magic-leap-community/superpoint` via Hugging Face
  Transformers (`SuperPointForKeypointDetection`).
- **LightGlue** — `ETH-CVG/lightglue_superpoint` via Hugging Face Transformers
  (`AutoModel`); confidence threshold 0.1.
- **SuperGlue** — the vendored `magic-leap/SuperGluePretrainedNetwork` repository
  (`src.matching.run_superglue_pair`, weights `indoor`/`outdoor`). The adapter is
  kept for completeness but is **not** part of the reported comparison tables.

No training is performed; only pretrained checkpoints are used (downloaded on
first use into the Hugging Face cache). Pretrained weights are not redistributed
in the submission.

---

## 8. Notes

- Results are reproducible on a clean environment with the versions in
  `requirements.txt`; the random seeds used by the custom BRIEF sampling
  patterns are fixed (`seed=0`).
- Datasets and pretrained weights are **not** included in the submission — only
  the download/placement instructions above.
