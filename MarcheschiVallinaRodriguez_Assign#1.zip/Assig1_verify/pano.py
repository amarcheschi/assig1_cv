"""Feature-based panorama stitching (Assignment Part 2).

Modular refactor of the original script. Same SIFT + ratio-test +
RANSAC pipeline and same averaging / feathering compositing, but as
reusable functions with a CLI entry point.

Usage:
    python pano.py                                  # default images below
    python pano.py Data/Panorama/keble_a.jpg Data/Panorama/keble_b.jpg
    python pano.py a.jpg b.jpg c.jpg --blend average --ref 1 --out pano.jpg

When positional images are given, ONLY those are stitched. Otherwise
DEFAULT_IMAGES are used.
"""

import argparse
import csv
import json
import time
from pathlib import Path

import cv2 as cv
import numpy as np

from src import config as C
from src.compose2 import compose_imgs, feather_weights
from src.detectors import build_detectors, detect_and_describe
from src.matching import ratio_match, run_lightglue_pair, unique_matches

# ---------------------------------------------------------------------------
# Defaults: the images already used in the original script.
# ---------------------------------------------------------------------------
DEFAULT_IMAGES = [
    "Data/Panorama/keble_a.jpg",
    "Data/Panorama/keble_b.jpg",
    "Data/Panorama/keble_c.jpg",
]
DEFAULT_RATIO = C.STITCH_RATIO
DEFAULT_RANSAC_T = C.STITCH_RANSAC_T
DEFAULT_CONFIGS = list(C.STITCH_CONFIGS)  # >=3 classical configs (§4)
LEARNED_CONFIG = "SP+LightGlue"  # opt-in via --config (§4, needs HF models)


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------
def load_pair(path):
    """Load image as (color, gray); raise if unreadable."""
    img_color = cv.imread(str(path))
    if img_color is None:
        raise FileNotFoundError(f"Could not read {path}")
    img_gray = cv.cvtColor(img_color, cv.COLOR_BGR2GRAY)
    return img_color, img_gray


def corners_of(h, w):
    return np.float32([[[0, 0]], [[w, 0]], [[w, h]], [[0, h]]])


# ---------------------------------------------------------------------------
# Features / matching via src modules (point 1: >=3 configs, same protocol)
# ---------------------------------------------------------------------------
_CLASSICAL_CACHE = None


def _classical():
    """Cached src.detectors registry {name: (det, norm, desc_obj)}."""
    global _CLASSICAL_CACHE
    if _CLASSICAL_CACHE is None:
        _CLASSICAL_CACHE = build_detectors()
    return _CLASSICAL_CACHE


def is_learned_config(name):
    return name == LEARNED_CONFIG


def extract_classical(config_name, grays):
    """Per-image (kp, des) with src.detectors.detect_and_describe."""
    det, norm, desc_obj = _classical()[config_name]
    kps, descs = [], []
    for g in grays:
        kp, des = detect_and_describe(det, desc_obj, g)
        kps.append(list(kp) if kp is not None else [])
        descs.append(des)
    return kps, descs, norm


def match_classical_to_ref(kp_ref, desc_ref, kp_i, desc_i, norm,
                           ratio=DEFAULT_RATIO):
    """src.matching ratio test (query=i -> train=ref) + one-to-one.

    Returns one-to-one ``good`` with queryIdx into kp_i (src) and
    trainIdx into kp_ref (dst), ready for H_i_to_ref estimation.
    """
    good, _ = ratio_match(desc_i, desc_ref, norm, ratio)
    if not good:
        return []
    return unique_matches(good)


def match_learned_to_ref(img_i, img_ref, threshold=0.1, device=None):
    """SP+LightGlue pair (src.matching) with query->i / train->ref.

    ``run_lightglue_pair`` returns already-paired point lists, so we call
    it as (i, ref): kp0=i (query side), kp1=ref (train side).
    """
    kp_i, kp_ref, good = run_lightglue_pair(img_i, img_ref,
                                            threshold=threshold,
                                            device=device)
    return kp_i, kp_ref, good


def estimate_H(kp_src, kp_dst, good, ransac_t=DEFAULT_RANSAC_T):
    """Estimate homography mapping src -> dst. Returns (H, mask)."""
    if good is None or len(good) < 4:
        return None, None
    pts_src = np.float32([kp_src[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    pts_dst = np.float32([kp_dst[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    H, mask = cv.findHomography(pts_src, pts_dst, cv.RANSAC, ransac_t)
    return H, mask


def pair_stats(kp_src, kp_dst, good, H, mask):
    """Step-7 numbers for one stitch pair (§3.1.7, no GT needed).

    Returns dict(n_matches, n_inliers, inlier_ratio, mean_resid_px,
    med_resid_px) where residuals are ||H·p_src - p_dst|| over RANSAC
    inliers. NaN residuals when no inliers.
    """
    n_matches = len(good) if good is not None else 0
    if H is None or mask is None or n_matches == 0:
        return dict(n_matches=n_matches, n_inliers=0, inlier_ratio=0.0,
                    mean_resid_px=float("nan"), med_resid_px=float("nan"))
    inl = mask.ravel() == 1
    n_in = int(inl.sum())
    if n_in == 0:
        return dict(n_matches=n_matches, n_inliers=0, inlier_ratio=0.0,
                    mean_resid_px=float("nan"), med_resid_px=float("nan"))
    p_src = np.float32([kp_src[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    p_dst = np.float32([kp_dst[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    proj = cv.perspectiveTransform(p_src[inl], H)
    errs = np.linalg.norm((proj - p_dst[inl]).reshape(-1, 2), axis=1)
    return dict(n_matches=n_matches, n_inliers=n_in,
                inlier_ratio=n_in / n_matches,
                mean_resid_px=float(errs.mean()),
                med_resid_px=float(np.median(errs)))


def save_match_viz(img_ref, kp_ref, img_i, kp_i, good, mask, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    if mask is not None:
        matches_mask = mask.ravel().tolist()
    else:
        matches_mask = None
    if matches_mask is not None:
        vis = cv.drawMatches(img_ref, kp_ref, img_i, kp_i, good, None,
                             matchColor=(0, 255, 0), singlePointColor=None,
                             matchesMask=matches_mask, flags=2)
    else:
        vis = cv.drawMatches(img_ref, kp_ref, img_i, kp_i, good, None,
                             matchColor=(0, 255, 0), flags=2)
    cv.imwrite(str(path), vis)


# ---------------------------------------------------------------------------
# Canvas + warping + blending (same math as original 3-image block)
# ---------------------------------------------------------------------------
def compute_canvas(shapes, Hs_to_ref, ref_idx):
    """Union of all image footprints in the reference frame.

    shapes: list of (h, w); Hs_to_ref[i] maps i -> ref (None for ref itself).
    Returns (T, new_w, new_h).
    """
    warped_corners = []
    for i, (h, w) in enumerate(shapes):
        c = corners_of(h, w)
        if i == ref_idx:
            warped_corners.append(c)
            continue
        if Hs_to_ref[i] is None:
            continue
        warped_corners.append(cv.perspectiveTransform(c, Hs_to_ref[i]))
    all_pts = np.vstack(warped_corners).reshape(-1, 2)
    xmin, ymin = all_pts.min(axis=0)
    xmax, ymax = all_pts.max(axis=0)
    tx = int(-np.floor(xmin)) if xmin < 0 else 0
    ty = int(-np.floor(ymin)) if ymin < 0 else 0
    new_w = int(np.ceil(xmax)) + tx
    new_h = int(np.ceil(ymax)) + ty
    T = np.array([[1.0, 0.0, tx], [0.0, 1.0, ty], [0.0, 0.0, 1.0]])
    return T, new_w, new_h, tx, ty


def warp_all_to_ref(colors, Hs_to_ref, ref_idx, T, new_w, new_h):
    """Warp every image into the common canvas. Returns (warps, masks)."""
    warps, masks = [], []
    h_r, w_r = colors[ref_idx].shape[:2]
    tx = int(round(T[0, 2]))
    ty = int(round(T[1, 2]))
    for i, img in enumerate(colors):
        h, w = img.shape[:2]
        if i == ref_idx:
            warp = np.zeros((new_h, new_w, img.shape[2]), dtype=img.dtype) \
                if img.ndim == 3 else np.zeros((new_h, new_w), dtype=img.dtype)
            warp[ty:ty + h, tx:tx + w] = img
            mask = np.zeros((new_h, new_w), dtype=bool)
            mask[ty:ty + h, tx:tx + w] = True
        else:
            warp = cv.warpPerspective(img, T @ Hs_to_ref[i], (new_w, new_h))
            mask_src = np.ones((h, w), dtype=np.uint8) * 255
            mask = (cv.warpPerspective(mask_src, T @ Hs_to_ref[i],
                                       (new_w, new_h),
                                       flags=cv.INTER_NEAREST) > 0)
        warps.append(warp)
        masks.append(mask)
    return warps, masks


def blend_average(warps, masks):
    """Pixel averaging in overlap (baseline). Masks eroded by 1px so the
    INTER_NEAREST mask ring does not pull black warp-fringe into the mean."""
    eroded = []
    for m in masks:
        m = np.asarray(m, dtype=bool)
        k = np.ones((3, 3), np.uint8)
        eroded.append(cv.erode(m.astype(np.uint8), k,
                               iterations=1).astype(bool) if m.any() else m)
    acc = np.zeros_like(warps[0], dtype=np.float32)
    count = np.zeros(eroded[0].shape, dtype=np.float32)
    for warp, m in zip(warps, eroded):
        acc[m] += warp[m].astype(np.float32) if warp.ndim == 2 \
            else warp[m].astype(np.float32)
        count[m] += 1.0
    pano = np.zeros_like(acc)
    valid = count > 0
    if acc.ndim == 3:
        pano[valid] = acc[valid] / count[valid][:, None]
    else:
        pano[valid] = acc[valid] / count[valid]
    return pano.astype(warps[0].dtype)


def blend_feather(warps, masks):
    """Distance-transform feathering (same as src.compose2).

    Replaces the old Gaussian-blurred-mask version, whose weights stayed
    >0 outside the valid footprint and mixed real pixels with the black
    warp background -- the translucent rectangles visible in the pano.
    Distance weights are exactly 0 outside the eroded mask, so invalid
    (black) pixels can never contribute.
    """
    weights, union = feather_weights([np.asarray(m, dtype=bool)
                                       for m in masks], erode_px=2)
    pano_f = np.zeros_like(warps[0], dtype=np.float32)
    for warp, w in zip(warps, weights):
        ww = w[:, :, None] if warp.ndim == 3 else w
        pano_f += ww * warp.astype(np.float32)
    pano = pano_f.astype(warps[0].dtype)
    pano[~union] = 0
    return pano


# ---------------------------------------------------------------------------
# Pipelines
# ---------------------------------------------------------------------------
def stitch_pair(img_ref, img_i, blend="feather",
                config="SIFT",
                ratio=DEFAULT_RATIO, ransac_t=DEFAULT_RANSAC_T,
                device=None, lg_threshold=0.1):
    """Two-image stitch via src.compose2 for one feature config."""
    gray_ref = cv.cvtColor(img_ref, cv.COLOR_BGR2GRAY) \
        if img_ref.ndim == 3 else img_ref
    gray_i = cv.cvtColor(img_i, cv.COLOR_BGR2GRAY) \
        if img_i.ndim == 3 else img_i
    t0 = time.perf_counter()
    if is_learned_config(config):
        kp_i, kp_ref, good = match_learned_to_ref(
            img_i, img_ref, threshold=lg_threshold, device=device)
        H, mask = estimate_H(kp_i, kp_ref, good, ransac_t)
    else:
        kps, descs, norm = extract_classical(config, [gray_ref, gray_i])
        (kp_ref, desc_ref), (kp_i, desc_i) = zip(kps, descs)
        good = match_classical_to_ref(kp_ref, desc_ref, kp_i, desc_i,
                                      norm, ratio)
        H, mask = estimate_H(kp_i, kp_ref, good, ransac_t)
    t_match = (time.perf_counter() - t0) * 1000.0
    if H is None:
        raise RuntimeError(f"[{config}] homography estimation failed "
                           f"({len(good)} good matches)")
    stats = pair_stats(kp_i, kp_ref, good, H, mask)
    stats.update(config=config, t_match_ms=round(t_match, 1))
    pano, disp = compose_imgs(img_ref, img_i, H, blend=blend)
    return pano, {"good": good, "H": H, "mask": mask,
                  "kp_ref": kp_ref, "kp_i": kp_i, "stats": stats}


def stitch_n(colors, grays, ref_idx, blend="feather",
             config="SIFT",
             ratio=DEFAULT_RATIO, ransac_t=DEFAULT_RANSAC_T,
             match_viz_prefix=None, device=None, lg_threshold=0.1):
    """N-image stitch with a common reference for one feature config."""
    learned = is_learned_config(config)
    if learned:
        kps = [None] * len(colors)  # filled per pair by LightGlue below
        norm = None
    else:
        kps, descs, norm = extract_classical(config, grays)
    Hs = [None] * len(colors)
    goods, masks = [None] * len(colors), [None] * len(colors)
    stat_rows = []
    for i in range(len(colors)):
        if i == ref_idx:
            continue
        t0 = time.perf_counter()
        if learned:
            kp_i, kp_ref, good = match_learned_to_ref(
                colors[i], colors[ref_idx],
                threshold=lg_threshold, device=device)
            kps[i] = kp_i
            kps[ref_idx] = kp_ref  # overwritten per pair; viz uses locals
        else:
            good = match_classical_to_ref(kps[ref_idx], descs[ref_idx],
                                          kps[i], descs[i], norm, ratio)
            kp_i, kp_ref = kps[i], kps[ref_idx]
        H, mask = estimate_H(kp_i, kp_ref, good, ransac_t)
        t_match = (time.perf_counter() - t0) * 1000.0
        if H is None:
            raise RuntimeError(
                f"[{config}] homography {i}->ref({ref_idx}) failed "
                f"({len(good)} good matches)")
        Hs[i], goods[i], masks[i] = H, good, mask
        st = pair_stats(kp_i, kp_ref, good, H, mask)
        st.update(config=config, pair=f"{i}->{ref_idx}",
                  t_match_ms=round(t_match, 1),
                  n_kp_src=len(kp_i), n_kp_dst=len(kp_ref))
        stat_rows.append(st)
        print(f"[{config}] pair {i}->{ref_idx}: matches={st['n_matches']} "
              f"inliers={st['n_inliers']} ratio={st['inlier_ratio']:.3f} "
              f"mean_resid={st['mean_resid_px']:.2f}px")
        if match_viz_prefix is not None:
            # good: query -> image i, train -> ref, so viz order is (i, ref)
            save_match_viz(colors[i], kp_i, colors[ref_idx], kp_ref,
                            good, mask, f"{match_viz_prefix}_{i}_to_ref.jpg")
    shapes = [c.shape[:2] for c in colors]
    T, new_w, new_h, _, _ = compute_canvas(shapes, Hs, ref_idx)
    warps, masks_bool = warp_all_to_ref(colors, Hs, ref_idx, T, new_w, new_h)
    if blend == "average":
        pano = blend_average(warps, masks_bool)
    elif blend == "feather":
        pano = blend_feather(warps, masks_bool)
    else:
        raise ValueError("blend must be 'average' or 'feather'")
    info = {"Hs": Hs, "T": T, "goods": goods, "masks": masks,
            "kps": kps, "canvas": (new_h, new_w), "stat_rows": stat_rows}
    return pano, info


# ---------------------------------------------------------------------------
# RANSAC threshold study (§3.2, SIFT only)
# ---------------------------------------------------------------------------
def ransac_study_sift(colors, grays, ref_idx, thresholds=None,
                      blend="feather", ratio=DEFAULT_RATIO,
                      out_stem="figures/pano_ransac",
                      matches_prefix="figures/matches_ransac",
                      stats_out="results/pano_ransac_study.csv"):
    """Re-run the SIFT stitch once per RANSAC threshold.

    Matching (ratio test) is identical every time; only
    ``cv.findHomography(..., RANSAC, t)`` changes. Returns the row list
    and writes one panorama + match viz per threshold plus a CSV.
    """
    thresholds = tuple(thresholds) if thresholds else tuple(C.RANSAC_STUDY)
    all_rows = []
    for t in thresholds:
        tag = str(t).replace(".", "p")
        pano, info = stitch_n(colors, grays, ref_idx, blend,
                               "SIFT", ratio, t,
                               f"{matches_prefix}_{tag}")
        for st in info["stat_rows"]:
            st = dict(st)
            st["ransac_t"] = t
            all_rows.append(st)
            print(f"[SIFT ransac={t}] pair {st['pair']}: "
                  f"matches={st['n_matches']} inliers={st['n_inliers']} "
                  f"ratio={st['inlier_ratio']:.3f} "
                  f"mean_resid={st['mean_resid_px']:.2f}px")
        out = f"{out_stem}_{tag}.jpg"
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        cv.imwrite(out, pano)
        print(f"[SIFT ransac={t}] wrote {out} shape={pano.shape}")
    if all_rows:
        Path(stats_out).parent.mkdir(parents=True, exist_ok=True)
        with open(stats_out, "w", newline="") as f:
            import csv as _csv
            w = _csv.DictWriter(f, fieldnames=sorted(all_rows[0].keys()))
            w.writeheader()
            w.writerows(all_rows)
        print(f"[ransac-study] wrote {stats_out} ({len(all_rows)} rows)")
    return all_rows


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="Feature-based panorama "
                                 "stitching (§3: multi-config + pair stats)")
    ap.add_argument("images", nargs="*",
                    help="images to stitch (default: %(default)s)")
    ap.add_argument("--ref", type=int, default=None,
                    help="reference index (default: middle image)")
    ap.add_argument("--blend", choices=["average", "feather"],
                    default="feather")
    ap.add_argument("--config", action="append", default=None,
                    help="feature config from src.detectors plus "
                    f"'{LEARNED_CONFIG}' (repeatable; default: "
                    f"{' '.join(DEFAULT_CONFIGS)})")
    ap.add_argument("--ratio", type=float, default=DEFAULT_RATIO)
    ap.add_argument("--ransac", type=float, default=DEFAULT_RANSAC_T)
    ap.add_argument("--out", default=None,
                    help="output panorama path (default figures/pano_abc.jpg "
                    "or figures/composedresults.jpg; multi-config: used as "
                    "stem prefix '<out>_<config>.jpg')")
    ap.add_argument("--matches-prefix", default="figures/matches",
                    help="prefix for per-pair match visualizations "
                    "(default figures/matches)")
    ap.add_argument("--stats-out", default="results/pano_stats.csv",
                    help="CSV file for per-pair stitching stats (§3.1.7)")
    ap.add_argument("--device", default=None,
                    help="torch device for the learned config (default: auto)")
    ap.add_argument("--lg-threshold", type=float, default=0.1,
                    help="LightGlue match confidence threshold")
    ap.add_argument("--ransac-study", action="store_true",
                    help="SIFT-only RANSAC threshold study (§3.2): rerun the "
                    f"stitch for ransac={list(C.RANSAC_STUDY)} and write one "
                    "panorama + CSV rows per threshold")
    ap.add_argument("--ransac-out", default="results/pano_ransac_study.csv",
                    help="CSV output for --ransac-study")
    return ap.parse_args(argv)


def _slug(name):
    return name.replace("+", "_").replace(" ", "")


def main(argv=None):
    args = parse_args(argv)
    paths = list(args.images) if args.images else list(DEFAULT_IMAGES)
    # Panorama is done ONLY on the images passed as arguments (or defaults
    # when none are given) -- no extra files are appended.
    ref_idx = args.ref if args.ref is not None else len(paths) // 2
    if not 0 <= ref_idx < len(paths):
        raise ValueError(f"--ref {ref_idx} out of range for "
                         f"{len(paths)} images")
    configs = list(args.config) if args.config else list(DEFAULT_CONFIGS)
    known = set(_classical()) | {LEARNED_CONFIG}
    for c in configs:
        if c not in known:
            raise ValueError(f"unknown --config {c!r}; choose from "
                             f"{sorted(known)}")
    colors, grays = [], []
    for p in paths:
        c, g = load_pair(p)
        colors.append(c)
        grays.append(g)
    print(f"[pano] stitching {len(paths)} images, ref={ref_idx} "
          f"({Path(paths[ref_idx]).name}), blend={args.blend}")
    for p in paths:
        print(f"       - {p}")
    print(f"[pano] configs: {' '.join(configs)} "
          f"(ratio={args.ratio}, ransac={args.ransac})")

    # Point 3 (§3.2): SIFT RANSAC-threshold study, same matches, 3 H estimates.
    if args.ransac_study:
        if args.out is None or len(configs) > 1:
            stem = "figures/pano_ransac"
        else:
            stem = str(Path(args.out).with_suffix(""))
        ransac_study_sift(colors, grays, ref_idx,
                           thresholds=tuple(C.RANSAC_STUDY),
                           blend=args.blend, ratio=args.ratio,
                           out_stem=stem,
                           matches_prefix=f"{args.matches_prefix}_ransac",
                           stats_out=args.ransac_out)
        # Fall through to the normal run below so the requested
        # --ransac panorama is still produced for comparison.

    all_rows = []
    for config in configs:
        tag = _slug(config)
        if len(paths) == 2:
            # Keep pair order generic: warp non-ref into ref.
            ref_first = (ref_idx == 0)
            img_ref = colors[0] if ref_first else colors[1]
            img_other = colors[1] if ref_first else colors[0]
            pano, info = stitch_pair(img_ref, img_other, args.blend,
                                     config, args.ratio, args.ransac,
                                     args.device, args.lg_threshold)
            st = dict(info["stats"])
            other_idx = 1 if ref_first else 0
            st.update(pair=f"{other_idx}->{ref_idx}")
            all_rows.append(st)
            print(f"[{config}] pair {st['pair']}: matches={st['n_matches']} "
                  f"inliers={st['n_inliers']} ratio={st['inlier_ratio']:.3f} "
                  f"mean_resid={st['mean_resid_px']:.2f}px")
            kp_ref, kp_i = info["kp_ref"], info["kp_i"]
            c_ref, c_i = img_ref, img_other
            # good: query -> other image, train -> ref normally; the
            # learned path already returns that orientation too.
            save_match_viz(c_i, kp_i, c_ref, kp_ref, info["good"],
                            info["mask"],
                            f"{args.matches_prefix}_{tag}_output.jpg")
            if args.out and len(configs) == 1:
                out = args.out
            elif args.out:
                out = str(Path(args.out).with_stem(
                    f"{Path(args.out).stem}_{tag}"))
            else:
                out = "figures/composedresults.jpg" if len(configs) == 1 else \
                    f"figures/composedresults_{tag}.jpg"
        else:
            pano, info = stitch_n(colors, grays, ref_idx, args.blend,
                                   config, args.ratio, args.ransac,
                                   f"{args.matches_prefix}_{tag}",
                                   args.device, args.lg_threshold)
            all_rows.extend(info["stat_rows"])
            if args.out and len(configs) == 1:
                out = args.out
            elif args.out:
                out = str(Path(args.out).with_stem(
                    f"{Path(args.out).stem}_{tag}"))
            else:
                out = "figures/pano_abc.jpg" if len(configs) == 1 else \
                    f"figures/pano_abc_{tag}.jpg"
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        cv.imwrite(out, pano)
        print(f"[{config}] wrote {out} shape={pano.shape}")

    # Point 2: persist §3.1.7 stats (one row per stitch pair per config).
    if all_rows:
        Path(args.stats_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.matches_prefix).parent.mkdir(parents=True, exist_ok=True)
        with open(args.stats_out, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=sorted(all_rows[0].keys()))
            w.writeheader()
            w.writerows(all_rows)
        print(f"[pano] wrote {args.stats_out} ({len(all_rows)} pair-rows)")
        cfg = {"images": paths, "ref_idx": ref_idx, "configs": configs,
               "blend": args.blend, "ratio": args.ratio,
               "ransac_t": args.ransac, "lg_threshold": args.lg_threshold,
               "stats_csv": args.stats_out}
        cfg_path = Path(args.stats_out).with_suffix(".json")
        cfg_path.write_text(json.dumps(cfg, indent=2))
        print(f"[pano] wrote {cfg_path}")
    return all_rows


if __name__ == "__main__":
    main()
